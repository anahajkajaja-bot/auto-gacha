# AUTO GACHA Android

Project Android native (Kotlin + Jetpack Compose).

## Build APK hanya menggunakan HP
1. Ekstrak ZIP ini menggunakan pengelola file.
2. Buat repository baru di https://github.com/new.
3. Upload seluruh isi folder project (termasuk folder tersembunyi `.github`) ke repository.
4. Buka tab **Actions** di repository.
5. Pilih **Build AUTO GACHA APK**, lalu tekan **Run workflow**.
6. Setelah selesai, buka hasil workflow dan unduh artifact **AUTO-GACHA-APK**.
7. Ekstrak artifact ZIP untuk mendapatkan `app-debug.apk`, lalu instal di Android.

Workflow memakai Java 17 dan Gradle 8.9 untuk membangun APK debug.

## Fitur
- Dashboard status Mulai/Jeda (demo UI)
- Counter status
- Editor antrean data uji
- Halaman Riwayat dan Pengaturan

## Batasan
Versi ini tidak membaca OTP/SMS, tidak mengendalikan WhatsApp, dan tidak melakukan pendaftaran akun massal. Tombol Mulai/Jeda hanya mengubah status demo.
