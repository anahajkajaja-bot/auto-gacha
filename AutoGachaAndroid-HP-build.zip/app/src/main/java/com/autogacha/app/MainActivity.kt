package com.autogacha.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF061F1B)
private val Panel = Color(0xFF0D3029)
private val Mint = Color(0xFF72DDAA)
private val Muted = Color(0xFF9AB7AC)
private val White = Color(0xFFEAF7F0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AutoGachaApp() }
    }
}

@Composable
fun AutoGachaApp() {
    var running by remember { mutableStateOf(false) }
    var queue by remember { mutableStateOf("") }
    var page by remember { mutableStateOf(0) }
    val count = queue.lines().count { it.trim().isNotEmpty() }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Mint,
        onPrimary = Color(0xFF073126), onSurface = White
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Mint) {
                    NavigationBarItem(selected = page == 0, onClick = { page = 0 },
                        icon = { Icon(Icons.Default.Home, null) }, label = { Text("Beranda") })
                    NavigationBarItem(selected = page == 1, onClick = { page = 1 },
                        icon = { Icon(Icons.Default.History, null) }, label = { Text("Riwayat") })
                    NavigationBarItem(selected = page == 2, onClick = { page = 2 },
                        icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Pengaturan") })
                }
            }
        ) { pad ->
            when (page) {
                0 -> HomeScreen(Modifier.padding(pad), running, { running = it }, queue, { queue = it }, count)
                1 -> HistoryScreen(Modifier.padding(pad))
                else -> SettingsScreen(Modifier.padding(pad))
            }
        }
    }
}

@Composable
fun HomeScreen(
    modifier: Modifier, running: Boolean, onRunning: (Boolean) -> Unit,
    queue: String, onQueue: (String) -> Unit, count: Int
) {
    LazyColumn(
        modifier.fillMaxSize().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 22.dp, bottom = 24.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Mint, RoundedCornerShape(14.dp)), Alignment.Center) {
                    Text("V+", color = Bg, fontWeight = FontWeight.Black, fontSize = 18.sp)
                }
                Spacer(Modifier.width(10.dp))
                Text("AUTO GACHA", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = White)
                Spacer(Modifier.weight(1f))
                Surface(color = Color(0xFF173D33), shape = CircleShape) {
                    Text("TEST MODE", Modifier.padding(horizontal = 13.dp, vertical = 8.dp),
                        color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            PanelCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(color = Color(0xFF174638), shape = CircleShape) {
                        Text(if (running) "Berjalan" else "Siap", Modifier.padding(horizontal = 13.dp, vertical = 7.dp),
                            color = Mint, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.weight(1f))
                    Text("$count antrean", color = Muted)
                }
                Spacer(Modifier.height(22.dp))
                Text(if (running) "RUNNING" else "IDLE", fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(18.dp))
                LinearProgressIndicator(progress = { if (running) 0.35f else 0f },
                    modifier = Modifier.fillMaxWidth().height(6.dp), color = Mint,
                    trackColor = Color(0xFF1A4439))
                Spacer(Modifier.height(20.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { onRunning(!running) }, modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Bg)) {
                        Icon(Icons.Default.PlayArrow, null)
                        Spacer(Modifier.width(5.dp))
                        Text(if (running) "Jeda" else "Mulai", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(onClick = { onRunning(false) }, modifier = Modifier.weight(1f),
                        border = ButtonDefaults.outlinedButtonBorder.copy(width = 1.dp)) {
                        Text("Hentikan", color = White)
                    }
                }
                Text("Mode demo: tombol hanya mengubah status tampilan.", color = Muted, fontSize = 11.sp)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                StatCard("0", "Siap", Mint, Modifier.weight(1f))
                StatCard("0", "Cooldown", Color(0xFFFFCE72), Modifier.weight(1f))
                StatCard("0", "Gagal", Color(0xFFFF8F9B), Modifier.weight(1f))
                StatCard("0", "Selesai", Color(0xFF8BC8EE), Modifier.weight(1f))
            }
        }
        item {
            PanelCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Antrean", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Text("Daftar data uji milik sendiri", color = Muted, fontSize = 12.sp)
                    }
                    Text("$count data", color = Mint, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = queue, onValueChange = onQueue,
                    modifier = Modifier.fillMaxWidth().height(150.dp),
                    placeholder = { Text("Tempel data uji, satu item per baris…", color = Muted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Mint, unfocusedBorderColor = Color(0xFF3B806A),
                        focusedTextColor = White, unfocusedTextColor = White
                    )
                )
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick = { onQueue("") }, modifier = Modifier.fillMaxWidth()) {
                    Text("Bersihkan antrean")
                }
            }
        }
        item {
            PanelCard {
                Text("Izin & keamanan", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Aplikasi ini belum membaca SMS, OTP, atau mengendalikan aplikasi lain. Gunakan hanya untuk antrean dan pengujian yang kamu miliki izin untuk lakukan.",
                    color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
            }
        }
    }
}

@Composable
fun PanelCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(24.dp))
            .border(1.dp, Color(0xFF245347), RoundedCornerShape(24.dp))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp), content = content
    )
}

@Composable
fun StatCard(value: String, label: String, color: Color, modifier: Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(18.dp)).padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = color, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun HistoryScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Riwayat", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        PanelCard { Text("Belum ada aktivitas.", color = Muted) }
    }
}

@Composable
fun SettingsScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Pengaturan", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        PanelCard {
            Text("Mode aplikasi", fontWeight = FontWeight.Bold)
            Text("Demo / antrean data uji", color = Mint)
            Text("Integrasi SMS dan otomasi eksternal tidak diaktifkan.", color = Muted, fontSize = 13.sp)
        }
        PanelCard {
            Text("Tentang", fontWeight = FontWeight.Bold)
            Text("AUTO GACHA • Versi 1.0", color = Muted)
        }
    }
}
